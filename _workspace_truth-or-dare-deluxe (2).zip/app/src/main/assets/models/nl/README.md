# Dutch ASR Model

This directory should contain the Dutch language model for Vosk ASR.

In a real implementation, you would need to download the Dutch model from:
https://alphacephei.com/vosk/models

The model should include the following files:
- final.conf
- am.model
- words.txt
- and other model files

The model will be unpacked to the device's internal storage on first run.